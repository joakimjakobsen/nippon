var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
var userMailInput = false;
var userPassword = false;

function TheLogin() {

    var userMail = document.getElementById("email").value;
    var password = document.getElementById("pw").value;

    if (userMail.match(validRegex)) {
        userMailInput = true;
    } else {
        alert("Hmm... tjek om emailen er skrevet rigtigt. Den skal indholde '@'.")
    }

    if (password.length < 8) {
        alert("Adgangskoden skal være min 8 tegn for, at den er sikker nok")
    } else {
        userPassword = true;
    }


    if (userMailInput == true && userPassword == true) {
        sessionStorage.setItem('usermail', userMail);
        sessionStorage.setItem('userpassword', password);
        top.location.href = "levering.html";
    }
}